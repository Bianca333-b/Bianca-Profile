// To access course code sent trough url from main page
const urlParams = new URLSearchParams(window.location.search);
const courseCode = urlParams.get('course');
const course = courses.find(course => course.code === courseCode);
if (course) {
    let courseTitle = course.title;
    document.getElementById('course-title').innerText = courseTitle;
    document.getElementById('course-code').innerText = courseCode;
}

document.getElementById('enrollmentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (validateForm()) {
        // Here you would typically send the form data to a server
        showCountdown(course);
        setTimeout(() => {
            window.location.href = "index.html";
        }, 30000);
        let enrolled = JSON.parse(localStorage.enrolled ?? '[]');
        enrolled = enrolled.filter(item => item.code !== course.code);
        enrolled.push(course);
        localStorage.enrolled = JSON.stringify(enrolled);
    }
});

function showCountdown(course) {
    const now = new Date();
    const timeLeft = course.startDate.getTime() - now.getTime();
    
    function updateCountdown() {
        const now = new Date();
        const timeLeft = course.startDate.getTime() - now.getTime();
        
        if (timeLeft < 0) {
            clearInterval(timer);
            document.querySelector('.countdown').innerHTML = '<h2>Your course has begun!</h2>';
            return;
        }

        const months = Math.floor(timeLeft / (1000 * 60 * 60 * 24 * 30));
        const days = Math.floor((timeLeft % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        document.querySelector('.countdown').innerHTML = `
            <div>
                <p>Months:</p>
                <h2>${months}</h2>
            </div>
            <div>
                <p>Days:</p>
                <h2>${days}</h2>
            </div>
            <div>
                <p>Hours:</p>
                <h2>${hours}</h2>
            </div>
            <div>
                <p>Minutes:</p>
                <h2>${minutes}</h2>
            </div>
            <div>
                <p>Seconds:</p>
                <h2>${seconds}</h2>
            </div>
        `;
    }

    let feedback = document.getElementById('form-container');
    
    feedback.innerHTML = `
        <div class="feedback-container">
            <h1>Enrollment Successful!</h1>
            <hr>
            <h3>You have successfully enrolled in:</h3>
            <h2>${course.title}</h2>

            <dotlottie-player src="https://lottie.host/2f163a9b-8815-4156-9d81-c5b893def5cf/rjDSxxy2dX.json" background="transparent" speed="1" style="width: 30%; margin: 0 auto;" loop autoplay></dotlottie-player>
            <h3 class="center">Start Date: <span>${course.startDate.toDateString()}</span></h3>
            <fieldset>
                <legend>&nbsp;Countdown Timer&nbsp;</legend>
                <div class="countdown">
                    <!-- Countdown will be inserted here by JavaScript -->
                </div>
            </fieldset>
            <p class="redirect-text">(This page will automatically redirect in 30 seconds...)</p>
        </div>
        <hr>
        <div class="form-footer">
            <div class="footer-content">
                <div class="contact">
                    <h4>Contact details</h4>
                    <div><i class="fa-solid fa-square-phone"></i><p><span id="phone">Phone: </span>  010 593 5368</p></div>
                    <div><i class="fa-solid fa-square-envelope"></i><p><span id="Email">Email: </span><span id="email"><a href=https://info@belgiumcampus.ac.za></a>info@belgiumcampus.ac.za</span></p></div>
                    <div><i class="fa-solid fa-map-location-dot"></i><p></p><span id="Adress"> Adress: </span><span><a href=https://maps.app.goo.gl/b3QLiPJNeXZi4ePq9>Pretoria Campus</a></span></p></div>
                </div>
                <img src="images/new_logo.png" alt="Belgium campus logo">
            </div>
            <div class="creators">
                <p>Developed by Jeremia, Tiaan and Bianca</p>
            </div>
        </div>
    `;
    const msg = feedback.querySelector('p.redirect-text');
    let seconds = 30;
    setInterval(() => {
        msg.innerText = `(This page will automatically redirect in ${--seconds} seconds...)`;
    }, 1000);
    updateCountdown(); // Initial call
    const timer = setInterval(updateCountdown, 1000); // Update every second
}

function validateForm() {
    let isValid = true;
    
    // Validate Full Name
    const fullName = document.getElementById('fullName');
    const fullNameError = document.getElementById('fullNameError');
    if (fullName.value.trim() === '') {
        fullNameError.textContent = 'Full name is required';
        isValid = false;
    } else {
        fullNameError.textContent = '';
    }

    // Validate Email
    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value)) {
        emailError.textContent = 'Please enter a valid email address';
        isValid = false;
    } else {
        emailError.textContent = '';
    }

    // Validate Phone
    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phoneError');
    const phonePattern = /^\d{10}$/;
    if (!phonePattern.test(phone.value)) {
        phoneError.textContent = 'Please enter a valid 10-digit phone number';
        isValid = false;
    } else {
        phoneError.textContent = '';
    }

    // Validate Date of Birth
    const dob = document.getElementById('dob');
    const dobError = document.getElementById('dobError');
    const today = new Date();
    const birthDate = new Date(dob.value);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    if (age < 16) {
        dobError.textContent = 'You must be at least 16 years old to enroll';
        isValid = false;
    } else {
        dobError.textContent = '';
    }

    return isValid;
}

