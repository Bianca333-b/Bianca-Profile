// DOM Element Selectors
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const courseList = document.getElementById('course-list');
const courseDetails = document.getElementById('course-details');
const completedModulesList = document.getElementById('completed-modules-list');

// Event Listeners
searchButton.addEventListener('click', searchCourses);

// Initialization
updateCompletedModulesList();
displayCourses(courses);

// Countdown Timer
function setupCountdown(element, date) {
    const updateCountdown = () => {
        const now = new Date();
        let seconds = (date.getTime() - now.getTime()) / 1000;
        const SecondsInMinute = 60;
        const SecondsInHour = SecondsInMinute * 60;
        const SecondsInDay = SecondsInHour * 24;
        let days = Math.floor(seconds / SecondsInDay);
        let hours = Math.floor((seconds % SecondsInDay) / SecondsInHour);
        let minutes = Math.floor((seconds % SecondsInHour) / SecondsInMinute);
        seconds = Math.floor(seconds % SecondsInMinute);
        element.innerText = '(' + [days, hours, minutes, seconds].map(item => item < 10 ? `0${item}` : item).join(':') + ' remaining)';
    };

    setInterval(updateCountdown, 1000);
}

// Search Functionality
function searchCourses() {
    const query = searchInput.value.toLowerCase();
    const filteredCourses = courses.filter(course => 
        course.title.toLowerCase().includes(query) || 
        course.code.toLowerCase().includes(query)
    );
    displayCourses(filteredCourses);
}

// Course Display
function displayCourses(coursesToShow) {
    courseList.innerHTML = '';
    const enrolled = JSON.parse(localStorage.enrolled ?? '[]');
    coursesToShow.forEach(course => {
        const courseCard = createCourseCard(course, enrolled);
        courseList.appendChild(courseCard);
    });
}

function createCourseCard(course, enrolled) {
    const courseCard = document.createElement('div');
    courseCard.classList.add('course-card');
    courseCard.innerHTML = `
        <h2 class="course-title">${course.title}</h2>
        <img src="${course.preview_image}" class="preview-image">
        <p><strong>Code:</strong> ${course.code}</p>
        <p><strong>Duration:</strong> ${course.duration}</p>
        <p>${course.description}</p>
        <div class="buttons">
            <button class="view-details" onclick="showCourseDetails('${course.code}')">View Details</button>
            <button class="enroll-button" onclick="enrollCourse('${course.code}')">Enroll</button>
        </div>
    `;
    const enrollButton = courseCard.querySelector('button.enroll-button');
    enrollButton.disabled = enrolled.find(item => item.code === course.code) !== undefined;
    if (enrollButton.disabled) {
        setupCountdown(enrollButton, course.startDate);
    }
    return courseCard;
}

// Course Details
function showCourseDetails(courseCode) {
    const course = courses.find(c => c.code === courseCode);
    if (course) {
        const completedModules = JSON.parse(localStorage.completedModules ?? '[]');
        courseDetails.innerHTML = createCourseDetailsHTML(course, completedModules);
        setupEnrollButton(course);
    }
    scrollToSection('course-details');
}

function createCourseDetailsHTML(course, completedModules) {
    return `
        <h2>${course.title}</h2>
        <table>
            <tr>
                <th>Module</th>
                <th>Lecturer</th>
                <th>Venue</th>
                <th colspan="3">Actions</th>
            </tr>
            ${course.modules.map(module => createModuleRowHTML(module, completedModules)).join('')}
        </table>
        <div class="view-details-btns">
            <button id="print-button" onclick="printCourseDetails('${course.code}')">Print Course</button>
            <button class="enroll-button" onclick="enrollCourse('${course.code}')">Enroll</button>
        </div>
    `;
}

function createModuleRowHTML(module, completedModules) {
    const isCompleted = completedModules.find(name => name === module.name) !== undefined;
    return `
        <tr ${isCompleted ? 'class="completed"' : ''}>
            <td>${module.name}</td>
            <td>${module.lecturer}</td>
            <td>${module.venue}</td>
            <td>
                <a href="#" onclick="downloadStudyGuide('${module.study_guide}', '${module.name}')">Download Study Guide</a>
            </td>
            <td>
                <a href="#" onclick="openVideoLink('${module.video_link}')">Watch Video</a>
            </td>
            <td>
                <button class="mark-as-completed-btn" onclick="markAsCompleted(this, '${module.name}')">Mark as Completed</button>
            </td>
        </tr>
    `;
}

function setupEnrollButton(course) {
    let enrolled = JSON.parse(localStorage.enrolled ?? '[]');
    if (enrolled.find(item => item.code === course.code) !== undefined) {
        const enrollBtn = courseDetails.querySelector('button.enroll-button');
        setupCountdown(enrollBtn, course.startDate);
        enrollBtn.disabled = true;
    }
}

// Module Completion
function markAsCompleted(button, moduleName) {
    let completedModules = JSON.parse(localStorage.completedModules ?? '[]');
    const completed = completedModules.find(name => name === moduleName) !== undefined;
    
    if (completed) {
        completedModules = completedModules.filter(name => name !== moduleName);
    } else {
        completedModules.push(moduleName);
    }
    
    localStorage.completedModules = JSON.stringify(completedModules);
    button.parentElement.parentElement.classList.toggle('completed');
    updateCompletedModulesList();
    updateProgressTracker();
    scrollToSection('completed-modules-list');
}

function updateCompletedModulesList() {
    let completedModules = JSON.parse(localStorage.completedModules ?? '[]');
    completedModulesList.innerHTML = '';
    completedModules.forEach(module => {
        const listItem = document.createElement('li');
        listItem.textContent = module;
        completedModulesList.appendChild(listItem);
    });
}

// Utility Functions
function downloadStudyGuide(studyGuide, moduleName) {
    if (studyGuide) {
        const link = document.createElement('a');
        link.href = studyGuide;
        link.download = `${moduleName.replace(/\s+/g, '_')}_Study_Guide.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    } else {
        alert(`Study guide for ${moduleName} is not available.`);
    }
}

function openVideoLink(videoLink) {
    window.open(videoLink, '_blank');
}

// function printCourseDetails(courseCode) {
//     const course = courses.find(c => c.code === courseCode);
//     if (!course) return;

//     const printWindow = window.open('', '_blank');
//     printWindow.document.write(`
//         <html>
//         <head>
//             <title>${course.title} - Course Details</title>
//             <style>
//                 body {
//                     font-family: Arial, sans-serif;
//                     line-height: 1.6;
//                     color: #333;
//                     padding: 20px;
//                 }
//                 h1 {
//                     color: #39C0C0;
//                 }
//                 table {
//                     width: 100%;
//                     border-collapse: collapse;
//                     margin-top: 20px;
//                 }
//                 th, td {
//                     border: 1px solid #ddd;
//                     padding: 8px;
//                     text-align: left;
//                 }
//                 th {
//                     background-color: #f2f2f2;
//                 }
//                 .logo {
//                     max-width: 200px;
//                     float: right;
//                 }
//             </style>
//         </head>
//         <body>
//             <img src="images/new_logo.png" alt="Belgium Campus Logo" class="logo">
//             <h1>${course.title}</h1>
//             <p><strong>Code:</strong> ${course.code}</p>
//             <p><strong>Duration:</strong> ${course.duration}</p>
//             <p><strong>Description:</strong> ${course.description}</p>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>Module</th>
//                         <th>Lecturer</th>
//                         <th>Venue</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     ${course.modules.map(module => `
//                         <tr>
//                             <td>${module.name}</td>
//                             <td>${module.lecturer}</td>
//                             <td>${module.venue}</td>
//                         </tr>
//                     `).join('')}
//                 </tbody>
//             </table>
//         </body>
//         </html>
//     `);
//     printWindow.document.close();
//     printWindow.print();
// }

function printCourseDetails(courseCode) {
    const course = courses.find(c => c.code === courseCode);
    if (!course) return;

    // Create a new iframe
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.body.appendChild(iframe);

    // Write the content to the iframe
    iframe.contentDocument.write(`
        <html>
        <head>
            <title>${course.title} - Course Details</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    padding: 20px;
                    background-image: url('${course.preview_image}');
                    background-size: cover;
                    background-repeat: no-repeat;
                    background-attachment: fixed;
                    background-position: center;
                    min-height: 100vh;
                }
                .content {
                    background-color: rgba(255, 255, 255, 0.9);
                    padding: 20px;
                    border-radius: 10px;
                    margin-bottom: 20px;
                }
                h1 {
                    color: #39C0C0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px;
                    text-align: left;
                }
                th {
                    background-color: #f2f2f2;
                }
                .logo {
                    margin-top: 10px;
                    max-width: 250px;
                    float: right;
                }
                a {
                    color: #39C0C0;
                    text-decoration: none;
                }
                a:hover {
                    text-decoration: underline;
                }
                @media print {
                    body {
                        -webkit-print-color-adjust: exact !important;
                        print-color-adjust: exact !important;
                    }
                    .content {
                        background-color: rgba(255, 255, 255, 0.9) !important;
                    }
                }
            </style>
        </head>
        <body>
            <div class="content">
                <img src="images/new_logo.png" alt="Belgium Campus Logo" class="logo">
                <h1>${course.title}</h1>
                <p><strong>Code:</strong> ${course.code}</p>
                <p><strong>Duration:</strong> ${course.duration}</p>
                <p><strong>Description:</strong> ${course.description}</p>
                <table>
                    <thead>
                        <tr>
                            <th>Module</th>
                            <th>Lecturer</th>
                            <th>Venue</th>
                            <th>Study Guide</th>
                            <th>Video Link</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${course.modules.map(module => `
                            <tr>
                                <td>${module.name}</td>
                                <td>${module.lecturer}</td>
                                <td>${module.venue}</td>
                                <td><a href="${module.study_guide}" target="_blank">Download</a></td>
                                <td><a href="${module.video_link}" target="_blank">Watch Video</a></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        </body>
        </html>
    `);

    iframe.contentDocument.close();

    // Ensure images are loaded before printing
    iframe.onload = function() {
        // Force background image to load
        const body = iframe.contentDocument.body;
        const bgImg = new Image();
        bgImg.src = course.preview_image;
        bgImg.onload = function() {
            // Short delay to ensure content is fully rendered
            setTimeout(() => {
                iframe.contentWindow.print();
                // Remove the iframe after printing
                setTimeout(() => {
                    document.body.removeChild(iframe);
                }, 1000);
            }, 500);
        };
        bgImg.onerror = function() {
            console.error('Failed to load background image:', course.preview_image);
            // Print even if the background image fails to load
            setTimeout(() => {
                iframe.contentWindow.print();
                setTimeout(() => {
                    document.body.removeChild(iframe);
                }, 1000);
            }, 500);
        };
    };
}

function enrollCourse(courseCode) {
    const course = courses.find(c => c.code === courseCode);
    if (course) {
      let enrolled = JSON.parse(localStorage.getItem('enrolled') || '[]');
      if (!enrolled.find(c => c.code === courseCode)) {
        enrolled.push(course);
        localStorage.setItem('enrolled', JSON.stringify(enrolled));
        alert(`You have successfully enrolled in ${course.title}`);
        
        // Update the enrollment button state
        const enrollButton = document.querySelector(`button[onclick="enrollCourse('${courseCode}')"]`);
        if (enrollButton) {
          enrollButton.disabled = true;
          enrollButton.textContent = 'Enrolled';
        }
        
        // Update the course timeline
        updateCourseTimeline();
      } else {
        alert(`You are already enrolled in ${course.title}`);
      }
    } else {
      alert('Course not found');
    }
  }

function scrollToSection(sectionId) {
    const targetSection = document.getElementById(sectionId);
    targetSection.scrollIntoView({behavior: 'smooth'});
}

function enrollCourse(courseCode) {
    const encodedString = encodeURIComponent(courseCode);
    window.location.href = `enroll_form.html?course=${encodedString}`;
}

function scrollToSection(sectionId) {
    const targetSection = document.getElementById(sectionId);
    targetSection.scrollIntoView({behavior: 'smooth'});
}

function updateProgressTracker() {
    // Get all completed modules from local storage
    const completedModules = JSON.parse(localStorage.getItem('completedModules') || '[]');
    
    // Calculate total modules across all courses
    const totalModules = courses.reduce((total, course) => total + course.modules.length, 0);
    
    // Calculate progress percentage
    const progressPercentage = (completedModules.length / totalModules) * 100;
    
    // Create or update the progress tracker element
    let progressTracker = document.getElementById('progress-tracker');
    if (!progressTracker) {
      progressTracker = document.createElement('div');
      progressTracker.id = 'progress-tracker';
      // Insert the progress tracker at the top of the main content
      const mainContent = document.querySelector('main');
      document.body.insertBefore(progressTracker, document.querySelector('footer'));
    }
    
    // Update the content of the progress tracker
    progressTracker.innerHTML = `
      <h2>Your Overall Progress</h2>
      <div class="progress-bar">
        <div class="progress" style="width: 0%"></div>
      </div>
      <p>${completedModules.length} out of ${totalModules} modules completed (${progressPercentage.toFixed(1)}%)</p>
    `;
    
    // Animate the progress bar
    setTimeout(() => {
      progressTracker.querySelector('.progress').style.width = `${progressPercentage}%`;
    }, 100);
  }
  
  // Call this function when the page loads and after marking a module as completed
  document.addEventListener('DOMContentLoaded', updateProgressTracker);

function createCourseTimeline() {
    const enrolled = JSON.parse(localStorage.getItem('enrolled') || '[]');
    
    if (enrolled.length === 0) {
      return ''; // Don't create a timeline if no courses are enrolled
    }
  
    const timeline = document.createElement('div');
    timeline.id = 'course-timeline';
    timeline.innerHTML = '<h2>Your Course Enrollment Timeline</h2>';
  
    const timelineBar = document.createElement('div');
    timelineBar.className = 'timeline-bar';
  
    const now = new Date();
    const threeYearsLater = new Date(now.getFullYear() + 3, now.getMonth(), now.getDate());
  
    enrolled.sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
  
    enrolled.forEach(course => {
      const startDate = new Date(course.startDate);
      if (startDate <= threeYearsLater) {
        const daysUntilStart = Math.floor((startDate - now) / (1000 * 60 * 60 * 24));
        const position = ((startDate - now) / (threeYearsLater - now)) * 100;
  
        const coursePoint = document.createElement('div');
        coursePoint.className = 'course-point';
        coursePoint.style.left = `${position}%`;
        coursePoint.innerHTML = `
          <div class="course-info">
            <h4>${course.title}</h4>
            <p>Starts in ${daysUntilStart} days</p>
            <p>Start Date: ${startDate.toDateString()}</p>
          </div>
        `;
  
        timelineBar.appendChild(coursePoint);
      }
    });
  
    timeline.appendChild(timelineBar);
    return timeline;
  }
  
  // Function to update the timeline
  function updateCourseTimeline() {
    const existingTimeline = document.getElementById('course-timeline');
    if (existingTimeline) {
      existingTimeline.remove();
    }
  
    const newTimeline = createCourseTimeline();
    if (newTimeline) {
      const mainContent = document.querySelector('main');
      mainContent.insertBefore(newTimeline, document.getElementById('course-details'));
    }
  }
  
  // Call this function when the page loads and after enrolling in a new course
  document.addEventListener('DOMContentLoaded', updateCourseTimeline);